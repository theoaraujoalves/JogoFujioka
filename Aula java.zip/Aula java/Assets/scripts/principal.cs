﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class principal : MonoBehaviour {


	public GameObject painelsim, painelnao;
	public bool aperto, fechado;


	// Use this for initialization
	void Start () {

		aperto = false;


	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void painelSim(){

		if (aperto == false) {
			painelsim.SetActive (true);
			aperto = true;
		} else if (aperto == true) {
			painelsim.SetActive (false);
			aperto = false;
		
		}

	}
		

	public void painelNao(){

		if (aperto == false) {
			painelnao.SetActive (true);
			aperto = true;
		} else if (aperto == true) {
			painelnao.SetActive (false);
			aperto = false;

		}

	}



}
